# Config Management Plugins Examples

| Application | Description |
|-------------|-------------|
| [kasane](kasane/) | The guestbook application as a `kasane` package. |
| [kustomized-helm](kustomized-helm/) | Application comprised of a `helm` chart and customized using `kustomize` |
